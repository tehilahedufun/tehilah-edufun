# Tehilah EduFun — Free First Version

A browser-based educational games platform for Nursery, Kindergarten and Primary learners.

## Included
- Ready-made games: phonics, CVC words, subitizing, number matching, shapes, addition, science, general knowledge, social studies, creative arts and PSED.
- Nursery / Kindergarten / Primary filters.
- Subject and game search.
- Teacher Studio for creating custom one-question games.
- Optional image upload for teacher-created games.
- Stars saved in the browser.
- Custom games saved in the browser using localStorage.
- No backend, API, paid service, database or account required.

## Run
1. Open `index.html` in Chrome, Edge or another modern browser.
2. For online lessons, share the browser window/screen.
3. Use Teacher Studio to create your own games.

## Important limitation of this first version
Custom games and stars are stored only in the browser/device where they were created. They are not yet synced between teachers/devices.

## Suggested next development
- Teacher accounts and cloud storage.
- Multiple questions per custom game.
- Picture-based answer choices.
- More game types (memory, matching, drag-and-drop, word search, bingo).
- Learner profiles, badges and progress dashboards.
- Publish as a free static website using a service such as GitHub Pages or Cloudflare Pages.
